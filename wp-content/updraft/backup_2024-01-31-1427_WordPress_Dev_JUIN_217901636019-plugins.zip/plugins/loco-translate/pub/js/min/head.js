"use strict";

!function(c, a) {
var b = a.getElementById("loco-fs");
a = a.getElementById("loco-main");
b && a && c.loco.fs.init(b).setForm(a);
}(window, document);